package com.example.cs360project;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    Activity activity;
    Button LoginButton, RegisterButton, ForgotPassButton;
    EditText Email, Password;
    String NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EmptyHolder;
    PopupWindow popwindow;
    SQLiteDatabase db;
    UsersSQLiteHandler handler;
    String TempPassword = "NOT_FOUND" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        activity = this;

        LoginButton = findViewById(R.id.signinButton);
        RegisterButton = findViewById(R.id.registerButton);
        ForgotPassButton = findViewById(R.id.forgotPasswordButton);
        Email = findViewById(R.id.editTextEmailAddress);
        Password = findViewById(R.id.editTextPassword);
        handler = new UsersSQLiteHandler(this);

        // click listener for forgotPasswordButton
        LoginButton.setOnClickListener(view -> {
            // Call Login function
            LoginFunction();
        });

        // click listener for register forgotPasswordButton.
        RegisterButton.setOnClickListener(view -> {
            // Opening new RegisterActivity using intent on forgotPasswordButton click.
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        //click listener for register forgotPasswordButton.
        ForgotPassButton.setOnClickListener(view -> {
            EmailHolder = Email.getText().toString().trim();

            if (!EmailHolder.isEmpty()) {
                forgotPassPopup();
            } else {
                Toast.makeText(LoginActivity.this, "User Email is Empty", Toast.LENGTH_LONG).show();
            }
        });
    }

    // Login function
    @SuppressLint("Range")
    public void LoginFunction() {
        String message = CheckEditTextNotEmpty();

        if(!EmptyHolder) {
            db = handler.getWritableDatabase();

            Cursor cursor = db.query(UsersSQLiteHandler.TABLE_NAME, null, " " + UsersSQLiteHandler.COLUMN_3_EMAIL + "=?", new String[]{EmailHolder}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    // Stores Password and Name associated with user email
                    TempPassword = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.COLUMN_4_PASSWORD));
                    NameHolder = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.COLUMN_1_NAME));
                    PhoneNumberHolder = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.COLUMN_2_PHONE_NUMBER));

                    cursor.close();
                }
            }
            handler.close();

            CheckFinalResult();
        } else {
            //If any of login fields are empty then this block will be executed.
            Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checks that editText fields are not empty.
    public String CheckEditTextNotEmpty() {
        // Gets value from fields and stores in string
        String message = "";
        EmailHolder = Email.getText().toString().trim();
        PasswordHolder = Password.getText().toString().trim();

        if (EmailHolder.isEmpty()){
            Email.requestFocus();
            EmptyHolder = true;
            message = "User Email is Empty";
        } else if (PasswordHolder.isEmpty()){
            Password.requestFocus();
            EmptyHolder = true;
            message = "User Password is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }


    public void CheckFinalResult(){
        if(TempPassword.equalsIgnoreCase(PasswordHolder)) {
            Toast.makeText(LoginActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();

            Bundle bundle = new Bundle();
            bundle.putString("user_name", NameHolder);
            bundle.putString("user_email", EmailHolder);
            bundle.putString("user_phone", PhoneNumberHolder);

            // Goes to ItemsListActivity after login
            Intent intent = new Intent(LoginActivity.this, ItemsListActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);

            EmptyEditTextAfterDataInsert();
        } else {
            // throws error if credentials are not correct
            Toast.makeText(LoginActivity.this,"Incorrect Email or Password\nor User Not Registered",Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND" ;
    }

    // edittext emptied after successful login
    public void EmptyEditTextAfterDataInsert() {
        Email.getText().clear();
        Password.getText().clear();
    }

    @SuppressLint("Range")
    public void forgotPassPopup() {
        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.forgot_password_popup, activity.findViewById(R.id.popup_element));

        popwindow = new PopupWindow(layout, 800, 800, true);
        popwindow.showAtLocation(layout, Gravity.CENTER, 0, 0);

        EditText phone = layout.findViewById(R.id.editTextItemDescriptionPopup);
        TextView password = layout.findViewById(R.id.textViewPassword);


        db = handler.getWritableDatabase();

        Cursor cursor = db.query(UsersSQLiteHandler.TABLE_NAME, null, " " + UsersSQLiteHandler.COLUMN_3_EMAIL + "=?", new String[]{EmailHolder}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();

                PhoneNumberHolder = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.COLUMN_2_PHONE_NUMBER));
                TempPassword = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.COLUMN_4_PASSWORD));

                cursor.close();
            }
        }
        handler.close();

        Button get = layout.findViewById(R.id.forgotGetButton);
        Button cancel = layout.findViewById(R.id.forgotCancelButton);

        get.setOnClickListener(view -> {
            String verifyPhone = phone.getText().toString();

            if(verifyPhone.equals(PhoneNumberHolder)) {
                password.setText(TempPassword);

                new android.os.Handler().postDelayed(() -> popwindow.dismiss(), 2000);
            } else {
                Toast.makeText(activity, "Phone Not Match", Toast.LENGTH_LONG).show();
            }
        });

        cancel.setOnClickListener(view -> {
            Toast.makeText(activity, "Action Canceled", Toast.LENGTH_SHORT).show();
            popwindow.dismiss();
        });
    }
}
