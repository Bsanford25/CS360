package com.example.cs360project;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class ItemsListActivity extends AppCompatActivity {

    TextView UserName, TotalItems;
    ImageButton AddItemButton, SmsButton, DelAllItemsButton;
    ListView ItemsListView;
    ItemsSQLiteHandler db;
    static String NameHolder, EmailHolder, PhoneNumHolder;
    AlertDialog AlertDialog = null;
    ArrayList<Item> items;
    CustomItemsList customItemsList;
    int itemsCount;

    public static final String UserEmail = "";
    private static final int USER_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private static boolean smsAuthorized = false;
    private static boolean deleteItems = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);

        //buttons, textViews, editText variables
        UserName = findViewById(R.id.textViewUserNameLabel);
        TotalItems = findViewById(R.id.textViewTotalItemsCount);
        AddItemButton = findViewById(R.id.addItemButton);
        SmsButton = findViewById(R.id.smsNotification);
        DelAllItemsButton = findViewById(R.id.deleteAllItemsButton);
        ItemsListView = findViewById(R.id.bodyListView);
        db = new ItemsSQLiteHandler(this);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            NameHolder = bundle.getString("user_name");
            EmailHolder = bundle.getString("user_email");
            PhoneNumHolder = bundle.getString("user_phone");

            UserName.setText(getString(R.string.salutation, NameHolder.toUpperCase()));
        }

        items = (ArrayList<Item>) db.getAllItems();

        itemsCount = db.getItemsCount();

        if (itemsCount > 0) {
            customItemsList = new CustomItemsList(this, items, db);
            ItemsListView.setAdapter((ListAdapter) customItemsList);
        } else {
            Toast.makeText(this, "Inventory is Empty", Toast.LENGTH_LONG).show();
        }

        TotalItems.setText(String.valueOf(itemsCount));

        // click listener for addItemButton
        AddItemButton.setOnClickListener(view -> {
            // Opening new AddItemActivity using intent on forgotPasswordButton click.
            Intent add = new Intent(this, AddItemsActivity.class);
            add.putExtra(UserEmail, EmailHolder);
            startActivityForResult(add, 1);
        });

        //click listener for smsNotification
        SmsButton.setOnClickListener(view -> {
            // Request sms permission for the device
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.SEND_SMS)) {
                    Toast.makeText(this,"SMS Permission is Needed", Toast.LENGTH_LONG).show();
                } else {
                    ActivityCompat.requestPermissions(this,
                            new String[] {Manifest.permission.SEND_SMS},
                            USER_PERMISSIONS_REQUEST_SEND_SMS);
                }
            } else {
                Toast.makeText(this,"SMS Permission is Allowed", Toast.LENGTH_LONG).show();
            }
            //SMS Alert
            AlertDialog = AD_SMSNotification.doubleButton(this);
            AlertDialog.show();
        });

        DelAllItemsButton.setOnClickListener(view -> {
            itemsCount = db.getItemsCount();

            if (itemsCount > 0) {
                // Open Delete Alert Dialog
                AlertDialog = AD_DeleteItems.doubleButton(this);
                AlertDialog.show();

                AlertDialog.setCancelable(true);
                AlertDialog.setOnCancelListener(dialog -> DeleteAllItems());
            } else {
                Toast.makeText(this, "Inventory is Empty", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_items_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.signoutMenuItem) {
            // End ItemsListActivity on menu item click.
            db.close();
            super.finish();
            Toast.makeText(this,"You Have Logged Out", Toast.LENGTH_LONG).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                itemsCount = db.getItemsCount();
                TotalItems.setText(String.valueOf(itemsCount));

                if(customItemsList == null)	{
                    customItemsList = new CustomItemsList(this, items, db);
                    ItemsListView.setAdapter((ListAdapter) customItemsList);
                }

                customItemsList.items = (ArrayList<Item>) db.getAllItems();
                ((BaseAdapter)ItemsListView.getAdapter()).notifyDataSetChanged();
            } else {
                Toast.makeText(this, "Action Canceled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static void YesDeleteItems() {
        deleteItems = true;
    }

    public static void NoDeleteItems() {
        deleteItems = false;
    }

    public void DeleteAllItems() {
        if (deleteItems) {
            db.deleteAllItems();
            Toast.makeText(this, "All Items have been Deleted", Toast.LENGTH_SHORT).show();
            TotalItems.setText("0");

            if (customItemsList == null) {
                customItemsList = new CustomItemsList(this, items, db);
                ItemsListView.setAdapter((ListAdapter) customItemsList);
            }

            customItemsList.items = (ArrayList<Item>) db.getAllItems();
            ((BaseAdapter) ItemsListView.getAdapter()).notifyDataSetChanged();
        }
    }

    public static void AllowSendSMS() {
        smsAuthorized = true;
    }

    public static void DenySendSMS() {
        smsAuthorized = false;
    }

    public static void SendSMSMessage(Context context) {
        String phoneNo = PhoneNumHolder;
        String smsMsg = "Hello, This message is to notify you that there are items with zero quantity in your inventory.";

        if (smsAuthorized) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNo, null, smsMsg, null, null);
                Toast.makeText(context, "SMS Sent", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(context, "Device Permission Denied", Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        } else {
            Toast.makeText(context, "App SMS Alert Disable", Toast.LENGTH_LONG).show();
        }
    }
}